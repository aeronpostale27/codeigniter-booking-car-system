<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managed_users extends CI_Controller{

	function __construct(){
		parent:: __construct();
		if(!$this->session->userdata('admin'))
			redirect('admin');
		$this->load->model('Admin_users', 'm');
	}

	function index(){

		$data['users'] = $this->m->getUser();
		$data['admins'] = $this->m->getAdmin();
		$this->load->view('admin/header');
		$this->load->view('admin/managed_users/index', $data);
		$this->load->view('admin/footer');
	}

	public function add(){
		$this->load->view('admin/header');
		$this->load->view('admin/managed_users/add');
	}

	public function add_admin(){
		$this->load->view('admin/header');
		$this->load->view('admin/managed_users/add_admin');
		$this->load->view('admin/footer');
	}

	public function submit(){
		$result = $this->m->submit();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiunto con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to add record');
		}
		redirect(base_url('admin/managed_users/index'));
	}

	public function submit_admin(){
		$result = $this->m->submit_admin();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiunto con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to add record');
		}
		redirect(base_url('admin/managed_users/index'));
	}

	public function edit($id){
		$data['user'] = $this->m->getUserById($id);
		$this->load->view('admin/header');
		$this->load->view('admin/managed_users/edit', $data);
		$this->load->view('admin/footer');
	}

	public function update(){
		$result = $this->m->update();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiornato con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to update record');
		}
		redirect(base_url('admin/managed_users'));
	}

	public function delete($id){
		$result = $this->m->delete($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('admin/managed_users/index'));
	}

	public function delete_admin($id){
		$result = $this->m->delete_admin($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('admin/managed_users/index'));
	}

	function deletealldata() {
		$result = $this->db->empty_table('driver_users');
		$this->db->truncate('driver_users');
		if ($result) {
			$this->session->set_flashdata('success_msg', 'Tutti i Dati cancellati con successo');
		} else {
			$this->session->set_flashdata('error_msg', 'Failed to Delete All Data');
		}
		redirect(base_url('admin/managed_users'));
	}
	
}