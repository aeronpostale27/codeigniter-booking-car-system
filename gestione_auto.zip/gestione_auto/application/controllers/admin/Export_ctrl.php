<?php
class Export_ctrl extends CI_Controller {
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		$this->load->view('admin/login');
	}

	function action() {
		$this->load->model('export_data');
		$this->load->library('excel');
		$object = new PHPExcel();

		$object->setActiveSheetIndex(0);
		$table_columns = array("Autista", "Nome della Macchina", "Codice", "Motivo", "Nota", "Destinazione", "Dal Giorno & Tempo", "Fino Giorno & Tempo", "Chilometraggio", "Creato", "Aggiornato");

		$column = 0;

		foreach($table_columns as $field) {
			$object->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
			$column++;
		}

		$reports_data = $this->export_data->fetch_reports();

		$excel_row = 2;

		foreach($reports_data as $row) {
			$object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row->driver_name);
			$object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row->car_name);
			$object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row->code);
			$object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row->code_add);
			$object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row->note);
			$object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row->destination);
			$object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row->from_day);
			$object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row->to_day);
			$object->getActiveSheet()->setCellValueByColumnAndRow(8, $excel_row, $row->mileage);
			$object->getActiveSheet()->setCellValueByColumnAndRow(9, $excel_row, $row->created_at);
			$object->getActiveSheet()->setCellValueByColumnAndRow(10, $excel_row, $row->updated_at);
			$excel_row++;
		}

		$object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="Reports-Data.xls"');
		$object_writer->save('php://output');

	}
	
}