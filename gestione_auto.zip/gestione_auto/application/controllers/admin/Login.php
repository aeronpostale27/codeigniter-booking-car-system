<?php
class Login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('admin'))
			redirect('admin/dashboard');
	}
	function index()
	{
		$this->load->view('admin/login');
	}
	function verify()
	{

		$this->load->model('admin');
		$check = $this->admin->validate();
		if($check)
		{  
			$this->session->set_userdata('admin','1');
			redirect('admin/dashboard');
		}
		else
		{
			$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
	        $this->form_validation->set_rules('username', 'Utente Nome', 'required');
	        $this->form_validation->set_rules('password', 'Password', 'required');

			if ($this->form_validation->run() == TRUE) {
	        	echo "<script>alert('Login: Nome utente o password non sono corretti');history.go(1);</script>";
	        }

	        $this->load->view('admin/login');
		} 
	}
}