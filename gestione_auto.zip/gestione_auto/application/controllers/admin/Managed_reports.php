<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managed_reports extends CI_Controller{

	function __construct(){
		parent:: __construct();
		if(!$this->session->userdata('admin'))
			redirect('admin');
		
		$this->load->model('Admin_reports', 'm');
	}

	function index() {
		$data['reports'] = $this->m->getReports();	
		$this->load->view('admin/header'); 
		$this->load->view('admin/managed_reports/index', $data);
		$this->load->view('admin/footer'); 
	}

	function deletealldata() {
		$result = $this->db->empty_table('reports');
		$this->db->truncate('reports');
		if ($result) {
			$this->session->set_flashdata('success_msg', 'Tutti i Dati cancellati con successo');
		} else {
			$this->session->set_flashdata('error_msg', 'Failed to Delete All Data');
		}
		redirect(base_url('admin/managed_reports'));
	}


	public function edit($id){
		$data['report'] = $this->m->getReportById($id);
		$data['cars'] = $this->m->getCars();
		$data['codici'] = $this->m->getCodici();
		$data['motivo'] = $this->m->getMotivo();
		$this->load->view('admin/header');
		$this->load->view('admin/managed_reports/edit', $data);
		$this->load->view('admin/footer');
	}

	public function update_one(){
		$result = $this->m->update_one();
	}

	public function update_two(){
		$result = $this->m->update_two();
	}

	public function delete($id){
		$result = $this->m->delete($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('admin/managed_reports/index'));
	}

}