<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managed_codici extends CI_Controller{

	function __construct(){
		parent:: __construct();
	 	if(!$this->session->userdata('admin'))
			redirect('admin');

		$this->load->model('Admin_codici', 'm');
	}

	function index(){

		$data['codici'] = $this->m->getCodici();
		$data['motivo'] = $this->m->getMotivo();
		$this->load->view('admin/header');
		$this->load->view('admin/managed_codici/index', $data);
		$this->load->view('admin/footer');
	}

	public function add(){
		$this->load->view('admin/header');
		$this->load->view('admin/managed_codici/add');
		$this->load->view('admin/footer');
	}

	public function add_motivo(){
		$this->load->view('admin/header');
		$this->load->view('admin/managed_codici/add_motivo');
		$this->load->view('admin/footer');
	}

	public function submit(){
		$result = $this->m->submit();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiunto con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to add record');
		}
		redirect(base_url('admin/managed_codici/index'));
	}

	public function submit_motivo(){
		$result = $this->m->submit_motivo();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiunto con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to add record');
		}
		redirect(base_url('admin/managed_codici/index'));
	}

	public function edit($id){
		$data['codice'] = $this->m->getCodiciById($id);
		$this->load->view('admin/header');
		$this->load->view('admin/managed_codici/edit', $data);
		$this->load->view('admin/footer');
	}

	public function edit_motivo($id){
		$data['motive'] = $this->m->getMotivoById($id);
		$this->load->view('admin/header');
		$this->load->view('admin/managed_codici/edit_motivo', $data);
		$this->load->view('admin/footer');
	}

	public function update(){
		$result = $this->m->update();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiornato con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to update record');
		}
		redirect(base_url('admin/managed_codici/index'));
	}

	public function update_motivo(){
		$result = $this->m->update_motivo();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiornato con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to update record');
		}
		redirect(base_url('admin/managed_codici/index'));
	}

	public function delete($id){
		$result = $this->m->delete($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('admin/managed_codici/index'));
	}

	public function delete_motivo($id){
		$result = $this->m->delete_motivo($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('admin/managed_codici/index'));
	}

	function deletealldata() {
		$result = $this->db->empty_table('codici');
		$this->db->truncate('codici');
		if ($result) {
			$this->session->set_flashdata('success_msg', 'Tutti i Dati cancellati con successo');
		} else {
			$this->session->set_flashdata('error_msg', 'Failed to Delete All Data');
		}
		redirect(base_url('admin/managed_codici'));
	}

}