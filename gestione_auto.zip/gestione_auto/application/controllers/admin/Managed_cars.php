<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managed_cars extends CI_Controller{

	function __construct(){
		parent:: __construct();
	 	if(!$this->session->userdata('admin'))
			redirect('admin');

		$this->load->model('Admin_cars', 'm');
	}

	function index(){

		$data['cars'] = $this->m->getCar();
		$this->load->view('admin/header');
		$this->load->view('admin/managed_cars/index', $data);
		// $this->load->view('admin/index', $data);
		$this->load->view('admin/footer');
	}

	public function add(){
		$this->load->view('admin/header');
		$this->load->view('admin/managed_cars/add');
		$this->load->view('admin/footer');
	}

	public function submit(){
		$result = $this->m->submit();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiunto con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to add record');
		}
		redirect(base_url('admin/managed_cars/index'));
	}

	public function edit($id){
		$data['car'] = $this->m->getCarById($id);
		$this->load->view('admin/header');
		$this->load->view('admin/managed_cars/edit', $data);
		$this->load->view('admin/footer');
	}

	public function update(){
		$result = $this->m->update();
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati aggiornato con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to update record');
		}
		redirect(base_url('admin/managed_cars/index'));
	}

	public function delete($id){
		$result = $this->m->delete($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('admin/managed_cars/index'));
	}

}