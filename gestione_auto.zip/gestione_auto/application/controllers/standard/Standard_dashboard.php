<?php
class standard_dashboard extends CI_Controller
{
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('Standard_home', 'm');
		if(!$this->session->userdata('user')) {
			redirect('home');
		}
	}

	public function index() {

		$data['cars'] = $this->m->getCars();
		$data['codici'] = $this->m->getCodici();
		$data['cars_avail'] = $this->m->getCarAvail();
		$data['reports'] = $this->m->getReports();
		$data['motivo'] = $this->m->getMotivo();
		$this->load->view('standard/header');
		$this->load->view('standard/standard_dashboard', $data);
		$this->load->view('standard/footer');

	}

	public function submit() {
		$result = $this->m->submit();
		if($result) {
			$this->session->set_flashdata('success_msg', 'Dati aggiunto con successo');
		} else {
			$this->session->set_flashdata('error_msg', 'Fail to add record');
		}
		redirect(base_url('standard/standard_dashboard/form_submit'));
	}

	public function form_submit() {
		$this->load->view('standard/form_submit');
	}

}

