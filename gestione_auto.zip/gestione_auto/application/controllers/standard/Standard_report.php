<?php
class standard_report extends CI_Controller
{
	function __construct()
	{
		parent:: __construct();
		$this->load->model('Standard_reports', 'm');
		if(!$this->session->userdata('user')) {
			redirect('home');
		}
	}

	public function index()
	{
		$data['reports'] = $this->m->getReports();
		$this->load->view('standard/header');
		$this->load->view('standard/standard_reports', $data);
		$this->load->view('standard/footer');
	}

	public function edit($id){
		$data['report'] = $this->m->getUserById($id);
		$this->load->view('standard/header');
		$this->load->view('standard/standard_edit', $data);
		$this->load->view('standard/footer');
	}

	public function modif($id){
		$data['cars'] = $this->m->getCars();
		$data['codici'] = $this->m->getCodici();
		$data['cars_avail'] = $this->m->getCarAvail();
		$data['report'] = $this->m->getUserById($id);
		$data['motivo'] = $this->m->getMotivo();
		$this->load->view('standard/header');
		$this->load->view('standard/standard_modif', $data);
		$this->load->view('standard/footer');
	}


	public function update_mileage() {

		$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
        $this->form_validation->set_rules('mileage', 'Chilomettraggio', 'min_length[6]|max_length[6]|required');


	        if ($this->form_validation->run() == FALSE) {
	        	echo "<script>alert('Deve essere Min/Mas di 6 numeri');history.go(-1);</script>";
	        } else {
				$result = $this->m->update_mileage();
				redirect(base_url('standard/standard_dashboard'));
			}

	}

	public function update_one() {
		$result = $this->m->update_one();
	}

	public function update_two() {
		$result = $this->m->update_two();
	}

	public function delete($id){
		$result = $this->m->delete($id);
		if($result){
			$this->session->set_flashdata('success_msg', 'Dati cancellati con successo');
		}else{
			$this->session->set_flashdata('error_msg', 'Fail to delete record');
		}
		redirect(base_url('standard/standard_dashboard/index'));
	}
}

