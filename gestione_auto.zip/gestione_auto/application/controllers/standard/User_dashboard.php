<?php
class user_dashboard extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('user'))
			redirect('home');
	}
	function index()
	{	
		$this->load->view('standard/header'); 
		$this->load->view('standard/standard_dashboard');
		$this->load->view('standard/footer'); 
	}
	function logout()
	{
		$this->session->sess_destroy();
		redirect('home');
	}
}