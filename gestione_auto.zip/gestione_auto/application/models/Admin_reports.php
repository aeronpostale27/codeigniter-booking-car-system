<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_reports extends CI_Model{


	public function getReports(){
		$this->db->order_by('created_at', 'desc');
		$query = $this->db->get('reports');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getCars() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('cars');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}


	public function getCodici() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('codici');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getMotivo() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('motivo_codici');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getReportById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('reports');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}

	public function update_one() {
       

       		$id = $this->input->post('txt_hidden');

			$field = array(
				'driver_name'=>$this->input->post('driver_name'),
				'code'=>$this->input->post('code'),
				'code_add'=>$this->input->post('code_add'),
				'note'=>$this->input->post('note'),
				'destination'=>$this->input->post('destination'),
				'mileage'=>$this->input->post('mileage'),
				'updated_at'=>date('Y-m-d H:i:s')
				);

			$this->db->where('id', $id);
			$this->db->update('reports', $field);
			redirect(base_url('admin/managed_reports'));

			echo $this->db->last_query();

			if($this->db->affected_rows() > 0){
				return true;
			} else {
				return false;
		}
}


	public function update_two() {

			$id = $this->input->post('txt_hidden');
			$field = array(
				'car_name'=>$this->input->post('car_name'),
				'from_day'=>$this->input->post('from_day'),
				'to_day'=>$this->input->post('to_day'),
				'updated_at'=>date('Y-m-d H:i:s')
				);

			$this->db->where('id', $id);
			$this->db->update('reports', $field);
			redirect(base_url('admin/managed_reports'));

			echo $this->db->last_query();

			if($this->db->affected_rows() > 0){
				return true;
			} else {
				return false;
		}
}

	public function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('reports');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

}