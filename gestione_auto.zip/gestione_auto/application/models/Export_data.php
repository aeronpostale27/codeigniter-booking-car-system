<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Export_data extends CI_Model {


	public function fetch_reports() {
		$this->db->order_by('created_at', 'desc');
		$query = $this->db->get('reports');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	


}