<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_cars extends CI_Model{


	public function getCar(){
		$this->db->order_by('created_at', 'desc');
		$query = $this->db->get('cars');
		// ---- For selecting specific data
		// $query = $this->db->get_where('cars', array('availability'=>'Available')); 
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}
  
	public function submit(){
		$field = array(
			'car_name'=>$this->input->post('car_name'),
			'plate_no'=>$this->input->post('plate_no'),
			'car_code'=>$this->input->post('car_code'),
			'availability'=>$this->input->post('availability'),
			'created_at'=>date('Y-m-d H:i:s')
			);
		$this->db->insert('cars', $field);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function getCarById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('cars');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}

	public function update() {

			$id = $this->input->post('txt_hidden');
			$field = array(
				'car_name'=>$this->input->post('car_name'),
				'plate_no'=>$this->input->post('plate_no'),
				'car_code'=>$this->input->post('car_code'),
				'exception'=>$this->input->post('exception'),
				'attention'=>$this->input->post('attention'),
				'availability'=>$this->input->post('availability'),
				'updated_at'=>date('Y-m-d H:i:s')
				);
			$this->db->where('id', $id);
			$this->db->update('cars', $field);

			echo $this->db->last_query();

			if($this->db->affected_rows() > 0){
				return true;
			} else {
				return false;
			}
	}

	public function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('cars');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

}