<?php
class Standard_login extends CI_Model
{
	function validate()
	{
		$arr['username'] = $this->input->post('name');
		$arr['password'] = md5($this->input->post('password'));
		return $this->db->get_where('driver_users',$arr)->row();
	}

	function admin_validate()
	{
		$arr['username'] = $this->input->post('name');
		$arr['password'] = md5($this->input->post('password'));
		return $this->db->get_where('admin_users',$arr)->row();
	}

} 