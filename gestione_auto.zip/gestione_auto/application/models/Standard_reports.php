<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Standard_reports extends CI_Model{


	public function getReports() {
		$this->db->order_by('id', 'desc');
		$query = $this->db->get('reports');
		return $query->result();

	}

	public function getCars() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('cars');
		if($query->num_rows() > 0){
			return $query->result();
		} else {			
			return false;
		}

	}

	
	public function getCarAvail(){
		$this->db->order_by('created_at', 'asc');
		// $query = $this->db->get('cars');
		// ---- For selecting specific data
		$query = $this->db->get_where('cars'); 
		if($query->num_rows() > 0){
			return $query->result();
		} else {
			return false;
		}

	}

	public function getCodici() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('codici');
		if($query->num_rows() > 0){
			return $query->result();
		} else {
			return false;
		}

	}

	public function getMotivo() {
		$query = $this->db->get('motivo_codici');
		if($query->num_rows() > 0) {
			return $query->result();
		}else{
			return false;
		}
	}

	public function getUserById($id) {
		$this->db->where('id', $id);
		$query = $this->db->get('reports');
		if($query->num_rows() > 0){
			return $query->row();
		} else {
			return false;
		}
	}

	public function update_mileage() {
		$id = $this->input->post('txt_hidden');
		$field = array(
			'mileage'=>$this->input->post('mileage'),
			'updated_at'=>date('Y-m-d H:i:s')
			);
		$this->db->where('id', $id);
		$this->db->update('reports', $field);

		echo $this->db->last_query();

		if($this->db->affected_rows() > 0) {
			$current_car_id = $this->input->post('car_id');

			$this->db->set('availability', 'Disponibile');
			$this->db->where('id', $current_car_id);
			$this->db->update('cars');
			return true;
		} else {
			return false;
		}
	}


	public function update_one() {

		            
			$id = $this->input->post('txt_hidden');

			$field = array(
				'driver_name'=>$this->input->post('driver_name'),
				'code'=>$this->input->post('code'),
				'code_add'=>$this->input->post('code_add'),
				'note'=>$this->input->post('note'),
				'destination'=>$this->input->post('destination'),
				'updated_at'=>date('Y-m-d H:i:s')
			);

			$this->db->where('id', $id);
			$this->db->update('reports', $field);
			redirect(base_url('standard/standard_dashboard'));

			echo $this->db->last_query();

			if($this->db->affected_rows() > 0) {
				return true;
			} else {
				return false;
			}

	}


	public function update_two() {

		$selected_from = $this->input->post('from_day'); // From form input
		$selected_to = $this->input->post('to_day');
		
		$selected_car = $this->input->post('car_name');
		$except_id = $this->input->post('txt_hidden');
		
		$num_reports = 0;
		
		$query_check1 = $this->db->query("SELECT * FROM reports WHERE id != '$except_id' AND  
									'$selected_from' >= from_day AND '$selected_from' <= to_day AND
									'$selected_car' = car_name ");
									
		$query_check2 = $this->db->query("SELECT * FROM reports WHERE id != '$except_id' AND 
									'$selected_to' >= from_day AND '$selected_to' <= to_day AND
									'$selected_car' = car_name ");

		$query_check3 = $this->db->query("SELECT * FROM reports WHERE id != '$except_id' AND 
									'$selected_from' <= from_day AND '$selected_to' >= to_day AND
									'$selected_car' = car_name ");
									

		$num_reports = $query_check1->num_rows() + $query_check2->num_rows() + $query_check3->num_rows();


       
		if($num_reports >=1) { //check results number of rows
			echo "<script>alert('Dati gia esiste');history.go(-1);</script>";
 		} else {

			$id = $this->input->post('txt_hidden');

			$field = array(
				'car_name'=>$this->input->post('car_name'),
				'from_day'=>$this->input->post('from_day'),
				'to_day'=>$this->input->post('to_day'),
				'updated_at'=>date('Y-m-d H:i:s')
			);

			$this->db->where('id', $id);
			$this->db->update('reports', $field);
			redirect(base_url('standard/standard_dashboard'));

			echo $this->db->last_query();

			if($this->db->affected_rows() > 0) {
				return true;
			} else {
				return false;
			}
		}
	}


	public function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('reports');
		if($this->db->affected_rows() > 0){
			return true;
		} else {
			return false;
		}
	}

}