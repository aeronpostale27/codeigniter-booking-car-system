<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_codici extends CI_Model {


	public function getCodici(){
		$this->db->order_by('created_at', 'asc');
		$query = $this->db->get('codici');
		// ---- For selecting specific data
		// $query = $this->db->get_where('cars', array('availability'=>'Available')); 
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getMotivo() {
		$query = $this->db->get('motivo_codici');
		if($query->num_rows() > 0) {
			return $query->result();
		}else{
			return false;
		}
	}
  
	public function submit(){
		$field = array(
			'nome'=>$this->input->post('nome'),
			'categoria'=>$this->input->post('categoria'),
			'created_at'=>date('Y-m-d H:i:s')
			);
		$this->db->insert('codici', $field);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function submit_motivo(){
		$field = array(
			'motivo'=>$this->input->post('motivo'),
			'created_at'=>date('Y-m-d H:i:s')
			);
		$this->db->insert('motivo_codici', $field);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}


	public function getCodiciById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('codici');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}

	public function getMotivoById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('motivo_codici');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}

	public function update(){
		$id = $this->input->post('txt_hidden');
		$field = array(
			'nome'=>$this->input->post('nome'),
			'categoria'=>$this->input->post('categoria'),
			'updated_at'=>date('Y-m-d H:i:s')
			);
		$this->db->where('id', $id);
		$this->db->update('codici', $field);
		echo $this->db->last_query();
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function update_motivo(){
		$id = $this->input->post('txt_hidden');
		$field = array(
			'motivo'=>$this->input->post('motivo'),
			'updated_at'=>date('Y-m-d H:i:s')
			);
		$this->db->where('id', $id);
		$this->db->update('motivo_codici', $field);
		echo $this->db->last_query();
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}


	public function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('codici');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function delete_motivo($id){
		$this->db->where('id', $id);
		$this->db->delete('motivo_codici');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

}