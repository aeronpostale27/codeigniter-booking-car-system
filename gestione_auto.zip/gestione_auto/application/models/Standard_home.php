<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Standard_home extends CI_Model{


	public function getCars() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('cars');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getReports() {
		$this->db->order_by('id', 'desc');
		$query = $this->db->get('reports');
		return $query->result();

	}
	
	public function getCarAvail() {
		$this->db->order_by('created_at', 'asc');
		// $query = $this->db->get('cars');
		// ---- For selecting specific data
		// $query = $this->db->get_where('cars', array('availability'=>'Disponibile')); 
		$query = $this->db->get_where('cars'); 
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getCodici() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('codici');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getMotivo() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('motivo_codici');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}


	public function submit(){
		
		$field = array(
			'driver_name'=>$this->input->post('driver_name'),
			'car_name'=>$this->input->post('car_id'),
			'car_id'=>$this->input->post('car_id'),
			'code'=>$this->input->post('code'),
			'code_add'=>$this->input->post('code_add'),
			'note'=>$this->input->post('note'),
			'destination'=>$this->input->post('destination'),
			'from_time'=>$this->input->post('from_time'),
			'to_time'=>$this->input->post('to_time'),
			'created_at'=>date('Y-m-d H:i:s')
			);

		$this->db->insert('reports', $field);
		
		if($this->db->affected_rows() > 0){
			$car_id_submitted = $this->input->post('car_id');

			$this->db->set('availability', 'Non Disponibile');
			$this->db->where('id', $car_id_submitted);
			$this->db->update('cars');

			return true;
		} else {
			return false;
		}

	}

	public function getUserById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('reports');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}

}