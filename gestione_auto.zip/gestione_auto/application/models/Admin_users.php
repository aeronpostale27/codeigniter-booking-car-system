<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_users extends CI_Model{


	public function getUser(){
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('driver_users');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getAdmin(){
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('admin_users');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function submit(){
		$field = array(
			'username'=>$this->input->post('username'),
			'name'=>$this->input->post('name'),
			'lastname'=>$this->input->post('lastname'),
			'password'=>md5($this->input->post('password')),
			'created_at'=>date('Y-m-d H:i:s')
			);
		$this->db->insert('driver_users', $field);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function submit_admin(){
		$field = array(
			'username'=>$this->input->post('username'),
			'password'=>md5($this->input->post('password')),
			'created_at'=>date('Y-m-d H:i:s')
			);
		$this->db->insert('admin_users', $field);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function getUserById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('driver_users');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}

	public function update(){
		$id = $this->input->post('txt_hidden');
		$field = array(
			'username'=>$this->input->post('username'),
			'name'=>$this->input->post('name'),
			'lastname'=>$this->input->post('lastname'),
			'updated_at'=>date('Y-m-d H:i:s')
			);
		$this->db->where('id', $id);
		$this->db->update('driver_users', $field);
		echo $this->db->last_query();extit;
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('driver_users');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function delete_admin($id){
		$this->db->where('id', $id);
		$this->db->delete('admin_users');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

}