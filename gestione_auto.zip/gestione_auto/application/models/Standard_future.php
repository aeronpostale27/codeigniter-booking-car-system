<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Standard_future extends CI_Model{


	public function getCars() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('cars');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}

	public function getCarAvail(){
		$this->db->order_by('created_at', 'asc');
		// $query = $this->db->get('cars');
		// ---- For selecting specific data
		$query = $this->db->get_where('cars', array('availability'=>'Disponibile')); 
		if($query->num_rows() > 0){
			return $query->result();
		} else {
			return false;
		}

	}

	public function getCodici() {
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('codici');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

	}



	public function submit() {


			$selected_from = $this->input->post('from_day'); // From form input
			$selected_to = $this->input->post('to_day');
			
			$selected_car = $this->input->post('car_id');
						
			
			$num_reports = 0;
			
			$query_check1 = $this->db->query("SELECT * FROM reports WHERE  
										'$selected_from' >= from_day AND '$selected_from' <= to_day AND
										'$selected_car' = car_name ");
										
			$query_check2 = $this->db->query("SELECT * FROM reports WHERE 
										'$selected_to' >= from_day AND '$selected_to' <= to_day AND
										'$selected_car' = car_name ");
										
			$query_check3 = $this->db->query("SELECT * FROM reports WHERE 
										'$selected_from' <= from_day AND '$selected_to' >= to_day AND
										'$selected_car' = car_name ");
				
			
			$num_reports = $query_check1->num_rows() + $query_check2->num_rows() + $query_check3->num_rows();
	       

	       
			if($num_reports >=1) { //check results number of rows
				echo "<script>alert('Dati gia esiste');history.go(-1);</script>";
				// redirect(base_url('standard/standard_dashboard/index'));
			} else {
				$field = array(
				'driver_name'=>$this->input->post('driver_name'),
				'car_name'=>$this->input->post('car_id'),
				'code'=>$this->input->post('code'),
				'code_add'=>$this->input->post('code_add'),
				'note'=>$this->input->post('note'),
				'destination'=>$this->input->post('destination'),
				'from_day'=>$this->input->post('from_day'),
				'to_day'=>$this->input->post('to_day'),
				'created_at'=>date('Y-m-d H:i:s')
			);

				$this->db->insert('reports', $field);
				redirect(base_url('standard/standard_dashboard/form_submit'));
			}


	}



	public function getUserById($id){
		$this->db->where('id', $id);
		$query = $this->db->get('reports');
		if ($query->num_rows() > 0) {
			return $query->row();
		} else {
			return false;
		}
	}

}