<!DOCTYPE html>
<html>
<head>
	<title>Admin - Dashboard</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/imagehover.min.css')?>">
	

	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-3.3.1.min.js')?>"></script>
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui.min.js')?>"></script>

	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap.css')?>">
	<link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap-glyphicons.css')?>" rel="stylesheet">
	<script type="text/javascript" src="<?php echo site_url('assets/bootstrap/dist/js/bootstrap.js')?>"></script>

	<script type="text/javascript" src="<?php echo site_url('assets/DataTables/datatables.min.js') ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/DataTables/datatables.min.css') ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui.min.css') ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui.structure.min.css') ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui.theme.min.css') ?>"/>
	
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui-timepicker-addon.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui.min.css') ?>"/>
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui-timepicker-addon.js') ?>"></script>
	
	<script type="text/javascript" src="<?php echo site_url('assets/js/datepicker_form.js') ?>"></script>

</head>

<style type="text/css">
		.navbar-light .navbar-nav .nav-link {
		    color: white;
		}

		.btn-info {
		    color: #fff;
		    background-color: #5ecbdd;
    		border-color: #5ecbdd;
		}

		.btn-primary {
		    color: #fff;
		    background-color: #359cc6;
		    border-color: #359cc6;
		}

		.btn-primary:hover {
		    color: #fff;
		    background-color: #4fafd6;
		    border-color: #4fafd6;
		}

		.table .thead-light th {
		    color: #ffffff;
		    background-color: #359cc6;
   			border-color: #359cc6;
		}

		.table {
			border: solid 3px; 
			border-color: #359cc6;
		}

		.page-item.active .page-link {
		    z-index: 1;
		    color: #fff;
		    background-color: #359cc6;
		    border-color: #359cc6;
		}

		.page-link {
		    color: #359cc6;
		}

		.form-control {
		    border: 1px solid #359cc6;
		}

		body {
			padding-bottom: 45px;
		}

		.container {
			padding-top: 55px;
		}

	@media print {
	  a[href]:after {
	    content: none !important;
	  }
	}

	@media (min-width: 1200px) {
		.container {
		    max-width: 1676px;
		}
	}

</style>

<body>
	<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #359cc6;">
	 

	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
    	  <li class="nav-item">
	         <a class="nav-link" href="<?php echo site_url('admin/dashboard')?>"><div style="font-weight: 500;">Focolari - Montet &nbsp;<span class="glyphicon glyphicon-home"></div></span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url('admin/managed_reports/index/');?>">Dati</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url('admin/managed_users/index/');?>">Utenti</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url('admin/managed_codici/index/');?>">Codici</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url('admin/managed_cars/index/');?>">Macchine</a>
	      </li>
	    </ul>

        <div class="" aria-labelledby="navbarDropdown">
          <a class="btn btn-danger" href="<?php echo site_url('admin/dashboard/logout')?>"><span class="glyphicon glyphicon-log-out"></span> Disconnetti</a>
        </div>

	  </div>
	</nav>
	<div class="container">