



<div class="row" style="margin-top: 120px;">
	<div class="col-md-12" align="center">

		<a href="<?php echo base_url("admin/managed_reports/index/"); ?>">
			<figure class="imghvr-zoom-out-left" style="margin-right: 30px;">
			  <img src="<?php echo base_url("assets/bootstrap/assets/img/icons/datix.svg"); ?>" height="280px;">
				  <figcaption>
				    <h2>Dati</h2> - Tutti i dati inviati gestite
				    <br><img src="<?php echo base_url("assets/bootstrap/assets/img/icons/datix.svg"); ?>" height="120px;">
				  </figcaption>
			</figure>
		</a>

		<a href="<?php echo base_url("admin/managed_users/index/"); ?>">
		<figure class="imghvr-zoom-in" style="margin-right: 30px;">
		  <img src="<?php echo base_url("assets/bootstrap/assets/img/icons/utentex.svg"); ?>" height="280px;">
			  <figcaption>
			    <h2>Utente</h2> - Tutte l'utente gestite
			    <br><img src="<?php echo base_url("assets/bootstrap/assets/img/icons/utentex.svg"); ?>" height="120px;">
			  </figcaption>
		</figure>
		</a>

		<a href="<?php echo base_url("admin/managed_codici/index/"); ?>">
		<figure class="imghvr-zoom-in" style="margin-right: 30px;">
		  <img src="<?php echo base_url("assets/bootstrap/assets/img/icons/codicix.svg"); ?>" height="280px;">
			  <figcaption>
			    <h2>Codici</h2> - Tutti i codici gestite
			    <br><img src="<?php echo base_url("assets/bootstrap/assets/img/icons/codicix.svg"); ?>" height="120px;">
			  </figcaption>
		</figure>
		</a>

		<a href="<?php echo base_url("admin/managed_cars/index/"); ?>">
		<figure class="imghvr-zoom-out-right" style="margin-right: 30px;">
		  <img src="<?php echo base_url("assets/bootstrap/assets/img/icons/carx.svg"); ?>" height="280px;">
			  <figcaption>
			    <h2>Macchine di dati</h2> - Tutte le Macchine gestite
			    <br><img src="<?php echo base_url("assets/bootstrap/assets/img/icons/carx.svg"); ?>" height="120px;">
			  </figcaption>
		</figure>
		</a>

	</div>
</div>

