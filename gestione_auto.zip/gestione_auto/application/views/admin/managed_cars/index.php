<style type="text/css">


	#title-header {
		margin-top: 30px;
		text-align: center;
	}
	
	#page-title {
		background: #359cc6;
		color: white;
		width: 350px;
		border-radius: 15px;
		padding: 10px;
		margin-bottom: 50px;
	}

	@media screen and (max-width: 800px) {
			#page-title {
			background: #359cc6;
			color: white;
			border-radius: 15px;
			padding: 10px;
			width: 350px;
			margin-bottom: 50px;
		}
	}


</style>




	<center><h3 id="page-title">Informazioni sulle auto</h3></center>



	<?php
		if($this->session->flashdata('success_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('success_msg'); ?>
		</div>
	<?php		
		}
	?>


	<?php
		if($this->session->flashdata('error_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('error_msg'); ?>
		</div>
	<?php		
		}
	?>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#car_data').DataTable();
	} );

</script>



	<div><a href="<?php echo base_url('admin/managed_cars/add'); ?>" class="btn btn-success"><span class="	glyphicon glyphicon-plus"></span> Aggiungere Nuovo</a></div> <br>

	<div class="table-responsive">
	<table id="car_data" class="table">
		<thead class="thead-light">
			<tr>
				<th>Macchina</th>
				<th>Targa</th>
				<th>Jubin</th>
				<th>Eccezione</th>
				<th>Attenzione</th>
				<th>Disponibilità</th>
				<th>Creato</th>
				<th>Aggiornato</th>
				<th>Modificare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			if($cars){
				foreach($cars as $car){
		?>
			<tr>
				<td><?php echo $car->car_name; ?></td>
				<td><?php echo $car->plate_no; ?></td>
				<td><?php echo $car->car_code; ?></td>
				<td><?php echo $car->exception; ?></td>
				<td><?php echo $car->attention; ?></td>
				<td><?php echo $car->availability; ?></td>
				<td><?php echo $car->created_at; ?></td>
				<td><?php echo $car->updated_at; ?></td>
				<td>

					<a href="<?php echo base_url('admin/managed_cars/edit/'.$car->id); ?>" class="btn btn-info"><span class="glyphicon glyphicon-edit"></span></a>
					<a href="<?php echo base_url('admin/managed_cars/delete/'.$car->id); ?>" class="btn btn-danger" onclick="return confirm('Davvero vuoi eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a>
				</td>
			</tr>
		<?php
				}
			}
		?>
		</tbody>
	</table>
</div>


