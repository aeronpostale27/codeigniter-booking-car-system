<br>	
	<a href="<?php echo base_url('admin/managed_cars/index'); ?>" style="float: right;" class="btn btn-dark"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>

	<h3>Aggiungere Macchina</h3> <br>

	
	<form action="<?php echo base_url('admin/managed_cars/submit') ?>" method="post" class="form-horizontal">
		<div class="form-group">
			<label for="title" class="col-md-2">Macchina</label>
			<div class="col-md-3">
				<input type="text" name="car_name" class="form-control" required>
			</div>
		</div>
		<div class="form-group">
			<label for="description" class="col-md-2">Targa</label>
			<div class="col-md-3">
				<input name="plate_no" class="form-control"></input>
			</div>
		</div>
		<div class="form-group">
			<label for="description" class="col-md-2">Jubin</label>
			<div class="col-md-3">
				<input name="car_code" class="form-control"></input>
			</div>
		</div>
		<div class="form-group">
			<div class="col-md-10">
				<input type="hidden" name="availability" class="form-control" value="Disponibile"></input>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-10">
				<input type="submit" name="btnSave" class="btn btn-primary" value="Salva">
			</div>
		</div>
	</form>
	
