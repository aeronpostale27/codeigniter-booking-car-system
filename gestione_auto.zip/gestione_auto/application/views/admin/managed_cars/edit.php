<br>		

	<a href="<?php echo base_url('admin/managed_cars/index'); ?>" style="float: right;" class="btn btn-dark"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>

	<h3>Modificare Macchine Dettagli</h3> <br>

<!-- 	<center> -->
		<form action="<?php echo base_url('admin/managed_cars/update') ?>" method="post" class="form-horizontal">
		<input type="hidden" name="txt_hidden" value="<?php echo $car->id; ?>">


		<div class="form-inline">
			<label for="title">Macchina</label>
			<div class="col-md-3">
				<input type="text" value="<?php echo $car->car_name; ?>" name="car_name" class="form-control" required>
			</div>

			<label for="description">Targa</label>
			<div class="col-md-3">
				<input name="plate_no" class="form-control" value="<?php echo $car->plate_no; ?>"></input>
			</div>

			<label for="description">Jubin</label>
			<div class="col-md-3">
				<input name="car_code" class="form-control" value="<?php echo $car->car_code; ?>"></input>
			</div>
		</div>

		<br>


		<div class="form-inline">
	
			<label for="description">Eccezione</label>
			<div class="col-md-3">
				<select class="form-control" name="exception">
					<option selected hidden><?php echo $car->exception; ?></option>
					<option value="">Niente</option>
					<option value="- Lunedi">- Lunedi</option>
					<option value="- Lun|Mar">- Lunedi|Martedi</option>
					<option value="- Lun|Mer">- Lunedi|Mercoledi</option>
					<option value="- Lun|Gio">- Lunedi|Giovedi</option>
					<option value="- Lun|Ven">- Lunedi|Venerdi</option>
					<option value="- Lun|Sab">- Lunedi|Sabato</option>
					<option value="- Lun|Dom">- Lunedi|Domenica</option>
					<option value="- Martedi">- Martedi</option>
					<option value="- Mar|Mer">- Martedi|Mercoledi</option>
					<option value="- Mar|Gio">- Martedi|Giovedi</option>
					<option value="- Mar|Ven">- Martedi|Venerdi</option>
					<option value="- Mar|Sab">- Martedi|Sabato</option>
					<option value="- Mar|Dom">- Martedi|Domenica</option>
					<option value="- Mercoledi">- Mercoledi</option>
					<option value="- Mer|Gio">- Mercoledi|Giovedi</option>
					<option value="- Mer|Ven">- Mercoledi|Venerdi</option>
					<option value="- Mer|Sab">- Mercoledi|Sabato</option>
					<option value="- Mer|Dom">- Mercoledi|Domenica</option>
					<option value="- Giovedi">- Giovedi</option>
					<option value="- Gio|Ven">- Giovedi|Venerdi</option>
					<option value="- Gio|Sab">- Giovedi|Sabato</option>
					<option value="- Gio|Dom">- Giovedi|Domenica</option>
					<option value="- Venerdi">- Venerdi</option>
					<option value="- Ven|Sab">- Venerdi|Sabato</option>
					<option value="- Ven|Dom">- Venerdi|Domenica</option>
					<option value="- Sabato">- Sabato</option>
					<option value="- Sab|Dom">- Sabato|Domenica</option>
					<option value="- Domenica">- Domenica</option>
				</select>
			</div>

			<label for="description">Attenzione</label>
			<div class="col-md-3">
				<input name="attention" class="form-control" value="<?php echo $car->attention; ?>"></input>
			</div>
	
			<label for="description">Disponibilità</label>
			<div class="col-md-3">
				<select class="form-control" name="availability">
					<option selected hidden><?php echo $car->availability; ?></option>
					<option style="color: green;">Disponibile</option>
					<option style="color: red;">Non Disponibile</option>
				</select>
			</div>
		</div>

		<br>

		<div class="form-group">
			<div class="col-md-4">
				<input type="submit" name="btnUpdate" class="btn btn-primary" value="Aggiorna">
			</div>
		</div>
	</form>
<!-- </center>
 -->
