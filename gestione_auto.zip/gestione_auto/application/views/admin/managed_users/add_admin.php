 <br>
	
<a href="<?php echo base_url('admin/managed_users/index'); ?>" class="btn btn-dark" style="float:right; margin-top: 10px;" ><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>


<h2>Aggiungere Utente</h2>  <br>

	<form action="<?php echo base_url('admin/managed_users/submit_admin') ?>" method="post" class="form-horizontal">
		<div class="form-group">
			<label for="title" class="col-md-2">Nome Utente</label>
			<div class="col-md-4">
				<input type="text" name="username" class="form-control" required>
			</div>
		</div>
		<div class="form-group">
			<label for="lastname" class="col-md-2">Password</label>
			<div class="col-md-4">
				<input type="text" minlength="6" name="password" class="form-control" required>
			</div>
		</div>

		<div class="form-group">
			<label class="col-md-2 text-right"></label>
			<div class="col-md-6">
				<input type="submit" name="btnUpdate" class="btn btn-primary" value="Salva">
			</div>
		</div>
	</form>
	
