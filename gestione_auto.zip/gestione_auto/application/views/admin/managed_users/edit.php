 <br>
	
<a href="<?php echo base_url('admin/managed_users/index'); ?>" class="btn btn-dark" style="float:right; margin-top: 10px;" ><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>


<h2>Modificare Utente</h2>  <br>

	<form action="<?php echo base_url('admin/managed_users/update') ?>" method="post" class="form-horizontal">
		<input type="hidden" name="txt_hidden" value="<?php echo $user->id; ?>">
		<div class="form-group">
			<label for="title" class="col-md-2">Nome Utente</label>
			<div class="col-md-4">
				<input type="text" value="<?php echo $user->username; ?>" name="username" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label for="lastname" class="col-md-2">Nome</label>
			<div class="col-md-4">
				<input type="text" value="<?php echo $user->name; ?>" name="name" class="form-control" >
			</div>
		</div>
		<div class="form-group">
			<label for="lastname" class="col-md-2">Cognome</label>
			<div class="col-md-4">
				<input type="text" value="<?php echo $user->lastname; ?>" name="lastname" class="form-control" >
			</div>
		</div>

		<div class="form-group">
			<label class="col-md-2 text-right"></label>
			<div class="col-md-6">
				<input type="submit" name="btnUpdate" class="btn btn-primary" value="Aggiorna">
			</div>
		</div>
	</form>
	

