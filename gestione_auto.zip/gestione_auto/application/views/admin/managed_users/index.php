<style type="text/css">
	
	#deleteall {
		float: right;
	}

	#title-header {
		margin-top: 30px;
		text-align: center;
	}

	#page-title {
		background: #359cc6;
		color: white;
		width: 310px;
		border-radius: 15px;
		padding: 10px;
		margin-bottom: 50px;
	}

	@media screen and (max-width: 800px) {
			#page-title {
			background: #359cc6;
			color: white;
			border-radius: 15px;
			padding: 10px;
			width: 310px;
			margin-bottom: 50px;
		}
	}


	
	
</style>


	<center><h3 id="page-title">Tutti Utenti Normali</h3></center>

	<?php
		if($this->session->flashdata('success_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('success_msg'); ?>
		</div>
	<?php		
		}
	?>


	<?php
		if($this->session->flashdata('error_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('error_msg'); ?>
		</div>
	<?php		
		}
	?>


	<div align="">
			<a href="<?php echo base_url('admin/managed_users/add'); ?>" class="btn btn-success"><span class="	glyphicon glyphicon-plus"></span> Aggiungere Nuovo </a>
			<a href="<?php echo base_url(); ?>admin/managed_users/deletealldata" class="btn btn-danger" id="deleteall" onclick="return confirm('Vuoi Eliminare Tutti i Dati Permanentemente?');"><span class="glyphicon glyphicon-remove-circle"></span> Eliminare Tutti Dati</a>
	</div><br>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#user_data').DataTable();
	} );

</script>
	
<div class="table-responsive">
	<table id="user_data" class="table">
		<thead class="thead-light">
			<tr>
				<th>Nome Utente</th>
				<th>Nome</th>
				<th>Cognome</th>
				<th>Creato</th>
				<th>Aggiornato</th>
				<th>Modificare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			if($users){
				foreach($users as $user){
		?>
			<tr>
				<td><?php echo $user->username; ?></td>
				<td><?php echo $user->name; ?></td>
				<td><?php echo $user->lastname; ?></td>
				<td><?php echo $user->created_at; ?></td>
				<td><?php echo $user->updated_at; ?></td>
				<td>

					<a href="<?php echo base_url('admin/managed_users/edit/'.$user->id); ?>" class="btn btn-info"><span class="glyphicon glyphicon-edit"></span></a>
					<a href="<?php echo base_url('admin/managed_users/delete/'.$user->id); ?>" class="btn btn-danger" onclick="return confirm('Vuoi davvero eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a>
				</td>
			</tr>
		<?php
				}
			}
		?>
		</tbody>
	</table>
</div>


	<br>

	<center><h3 id="page-title">Tutti Utenti Administratori</h3></center>


	<div><a href="<?php echo base_url('admin/managed_users/add_admin'); ?>" class="btn btn-success"><span class="	glyphicon glyphicon-plus"></span> Aggiungere Nuovo Admin </a></div> <br>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#admin_data').DataTable();
	} );

</script>
	
<div class="table-responsive">
	<table id="admin_data" class="table">
		<thead class="thead-light">
			<tr>
				<th>Nome Utente</th>
				<th>Creato</th>
				<th>Eliminare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			if($admins){
				foreach($admins as $admin){
		?>
			<tr>
				<td><?php echo $admin->username; ?></td>
				<td><?php echo $admin->created_at; ?></td>
				<td>

					<a href="<?php echo base_url('admin/managed_users/delete_admin/'.$admin->id); ?>" class="btn btn-danger" onclick="return confirm('Vuoi davvero eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a>
				</td>
			</tr>
		<?php
				}
			}
		?>
		</tbody>
	</table>
</div>
