<style type="text/css">
	
	a#deleteall {
		float: right;
	}


	#title-header {
		margin-top: 30px;
		text-align: center;
	}

	#page-title {
		background: #359cc6;
		color: white;
		width: 420px; 
		border-radius: 15px;
		padding: 10px;
		margin-bottom: 50px;
	}

	@media screen and (max-width: 800px) {
			#page-title {
			background: #359cc6;
			color: white;
			border-radius: 15px;
			padding: 10px;
			width: 400px;
			margin-bottom: 50px;
		}
	}


</style>


		<center><h3 id="page-title">Tutte le informazioni sui dati</h3></center>

			<?php
				if($this->session->flashdata('success_msg')){
			?>
				<div class="alert alert-success">
					<?php echo $this->session->flashdata('success_msg'); ?>
				</div>
			<?php		
				}
			?>


			<?php
				if($this->session->flashdata('error_msg')){
			?>
				<div class="alert alert-success">
					<?php echo $this->session->flashdata('error_msg'); ?>
				</div>
			<?php		
				}
			?>

		<div align="">
			<a href="<?php echo base_url(); ?>admin/export_ctrl/action" class="btn btn-success"><span class="glyphicon glyphicon-download-alt"></span> Scaricare Tutti Dati </a>
			<a href="<?php echo base_url(); ?>admin/managed_reports/deletealldata" class="btn btn-danger" id="deleteall" onclick="return confirm('Vuoi Eliminare Tutti i Dati Permanentemente?');"><span class="glyphicon glyphicon-remove-circle"></span> Eliminare Tutti Dati</a>
		</div><br>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#reports_data').DataTable();

	} );

</script>



<div class="table-responsive">
	<table id="reports_data" class="table">
		<thead class="thead-light">
			<tr>
				<th>ID</th>
				<th>Autista</th>
				<th>Macchina</th>
				<th>Codice</th>
				<th>Motivo</th>
				<th>Nota</th>
				<th>Destinazione</th>
				<th>Dal Giorno & Tempo</th>
				<th>Fino Giorno & Tempo</th>
				<th>Chilometraggio</th>
				<th>Creato</th>
				<th>Aggiornato</th>
				<th>Modificare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			if($reports){
				foreach($reports as $report){

				setlocale(LC_ALL, 'it_IT.UTF-8');
		?>
			<tr>
				<td><?php echo $report->id; ?></td>
				<td><?php echo $report->driver_name; ?></td>
				<td><?php echo $report->car_name; ?></td>
				<td><?php echo $report->code; ?></td>
				<td><?php echo $report->code_add; ?></td>
				<td><?php echo $report->note; ?></td>
				<td><?php echo $report->destination; ?></td>
				<td><?php echo $report->from_day; ?></td>
				<td><?php echo $report->to_day; ?></td>
				<td><?php echo $report->mileage; ?></td>
				<td><?php echo $report->created_at; ?></td>
				<td><?php echo $report->updated_at; ?></td>
				<td>	

					<a href="<?php echo base_url('admin/managed_reports/edit/'.$report->id); ?>" class="btn btn-info"><span class="glyphicon glyphicon-edit"></span></a>
					<a href="<?php echo base_url('admin/managed_reports/delete/'.$report->id); ?>" class="btn btn-danger" onclick="return confirm('Vuoi davvero eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a>
				</td>
			</tr>
		<?php
				}
			}
		?>
		</tbody>
	</table>
</div>



