<br>
	
<a href="<?php echo base_url('admin/managed_reports/index'); ?>" class="btn btn-dark" style="float:right;"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>


<h3>Modificare Dati</h3><br>

	<form action="<?php echo base_url('admin/managed_reports/update_one') ?>" method="post" class="form-horizontal">
		<input type="hidden" name="txt_hidden" value="<?php echo $report->id; ?>">



		<div class="form-group row">

		 <div class="col-4">
		  	<label for="">Austista</label>
		   	<input class="form-control" type="text" name="driver_name" value="<?php echo $report->driver_name; ?>" placeholder="Mettere Austista Nome">
		  </div>


		
		  <div class="col-4">
		  	<label for="">Codice</label>
		    <select name="code" class="form-control">
		    	<option value="<?php echo $report->code; ?>"><?php echo $report->code; ?></option>
		    	<?php 
			        foreach($codici as $codice)
			        { 
			          echo '<option value="'.$codice->nome.'">'.$codice->nome.'</option>';
			        }
		        ?>
		    </select>
		  </div>

		
		  <div class="col-4">
		  	<label for="">Nota</label>
		    <input class="form-control" type="text" value="<?php echo $report->note; ?>" placeholder="Nota" name="note">
		  </div>


		  <div class="col-4">
		  	<label for="">Destinazione</label>
		    <input class="form-control" type="text" value="<?php echo $report->destination; ?>" placeholder="Destinazione" name="destination">
		  </div>

		  <div class="col-2">
		  	<label for="">Motivo</label>
		    <select name="code_add" class="form-control">
		    	<option value="<?php echo $report->code_add; ?>"><?php echo $report->code_add; ?></option>
		    	<option value=""></option>
		    	<?php 
			        foreach($motivo as $motiv)
			        { 
			          echo '<option value="'.$motiv->motivo.'">'.$motiv->motivo.'</option>';
			        }
		        ?>
		    </select>
		  </div>

		  <div class="col-2">
		  	<label for="">Chilometraggio</label>
		    <input class="form-control" type="text" value="<?php echo $report->mileage; ?>" placeholder="Chilometraggio" name="mileage">
		  </div>



		</div>




		
		<input type="submit" name="btnUpdate" class="btn btn-primary" value="Aggiorna">


	</form>
	

<br><br><br>
	


	<h3>Modificare Macchina e Date</h3><br>


	<form action="<?php echo base_url('admin/managed_reports/update_two') ?>" method="post" class="form-horizontal">
		<input type="hidden" name="txt_hidden" value="<?php echo $report->id; ?>">



			<div class="form-group row">
		 
		 <div class="col-4">
		  	<label for="">Macchina</label>
		    <select name="car_name" id="exception" class="form-control">
	    		<option selected value="<?php echo $report->car_name; ?>""><?php echo $report->car_name; ?></option>
		    	 <?php 
			        foreach($cars_avail as $car_avail) 
			        { 
			          echo '<option value="'.$car_avail->car_name.'">'.$car_avail->car_name . ' '. $car_avail->exception. $car_avail->attention.'</option>';
			        }
		        ?>
		    </select>
		  </div> 
		</div>

<script type="text/javascript">

	var d = new Date();
    var n = d.getDay()

    var get;

	    if (n == 1) {
	    	$("select option:contains('- Lunedi')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mar')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mer')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Gio')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Dom')").attr("disabled","disabled");
	    } else if (n == 2) {
	    	$("select option:contains('- Martedi')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Mer')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Gio')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mar')").attr("disabled","disabled");
	    } else if (n == 3) {
	    	$("select option:contains('- Mercoledi')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Gio')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mer')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Mer')").attr("disabled","disabled");
	    } else if (n == 4) {
	    	$("select option:contains('- Giovedi')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Gio')").attr("disabled","disabled");	
	    	$("select option:contains('- Mar|Gio')").attr("disabled","disabled");   
	    	$("select option:contains('- Mer|Gio')").attr("disabled","disabled"); 	
	    } else if (n == 5) {
	    	$("select option:contains('- Venerdi')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Ven')").attr("disabled","disabled");
	    } else if (n == 6) {
	    	$("select option:contains('- Sabato')").attr("disabled","disabled");
	    	$("select option:contains('- Sab|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Sab')").attr("disabled","disabled");
	    } else if (n == 7) {
	    	$("select option:contains('- Domenica')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Sab|Dom')").attr("disabled","disabled");
	    } else {
	    	// alert('good');
	    }

</script>

		
		<div class="form-group row">
		  <div class="col-2">
		  	<?php echo form_error('from_day'); ?>
		  	<label for="">Giorno & Tempo Dal</label>
		    <input id="txtFromDate" class="form-control" type="text" value="<?php echo $report->from_day; ?>" minlength="16" maxlength="16" placeholder="Giorno Dal" name="from_day">
		  </div>

		  <div class="col-2">
		  	<?php echo form_error('to_day'); ?>
		  	<label for="">Giorno & Tempo Fino</label>
		    <input id="txtToDate" class="form-control" type="text" value="<?php echo $report->to_day; ?>" minlength="16" maxlength="16" placeholder="Giorno Fino" name="to_day">
		  </div>

		</div>

		
		<input type="submit" name="btnUpdate" class="btn btn-primary" value="Aggiorna">

	  </div>

		

	</form>
	

