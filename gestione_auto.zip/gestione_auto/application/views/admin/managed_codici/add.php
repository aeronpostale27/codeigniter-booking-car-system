<br>	
	<a href="<?php echo base_url('admin/managed_codici/index'); ?>" style="float: right;" class="btn btn-dark"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>

	<h3>Aggiungere Codice</h3> <br>

	
	<form action="<?php echo base_url('admin/managed_codici/submit') ?>" method="post" class="form-horizontal">
		<div class="form-group">
			<label for="title" class="col-md-2">Codice</label>
			<div class="col-md-3">
				<input type="text" name="nome" class="form-control" placeholder="Es. 07 - Bethanie" required>
			</div>
		</div>
		<div class="form-group">
			<label for="description" class="col-md-2">Categoria</label>
			<div class="col-md-3">
				<input name="categoria" class="form-control" placeholder="Es. Codice F"></input>
			</div>
		</div>
		
		<div class="form-group">
			<div class="col-md-10">
				<input type="submit" name="btnSave" class="btn btn-primary" value="Salva">
			</div>
		</div>
	</form>
	
