 <br>
	
<a href="<?php echo base_url('admin/managed_codici/index'); ?>" class="btn btn-dark" style="float:right; margin-top: 10px;" ><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>


<h2>Aggiungere Motivo</h2>  <br>

	<form action="<?php echo base_url('admin/managed_codici/submit_motivo'); ?>" method="post" class="form-horizontal">
		
		<div class="form-group">
			<label for="motivo" class="col-md-2">Motivo</label>
			<div class="col-md-2">
				<input type="text" name="motivo" placeholder="S - Sport" class="form-control" >
			</div>
		</div>

		<div class="form-group">
			<label class="col-md-2 text-right"></label>
			<div class="col-md-6">
				<input type="submit" name="btnUpdate" class="btn btn-primary" value="Salva">
			</div>
		</div>
	</form>
	
