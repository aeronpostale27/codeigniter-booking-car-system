<style type="text/css">


	#title-header {
		margin-top: 30px;
		text-align: center;
	}

	a#deleteall {
		float: right;
	}

	#page-title {
		background: #359cc6;
		color: white;
		border-radius: 15px;
		padding: 10px;
		width: 460px;
		margin-bottom: 50px;
	}

	@media screen and (max-width: 800px) {
			#page-title {
			background: #359cc6;
			color: white;
			border-radius: 15px;
			padding: 10px;
			width: 400px;
			margin-bottom: 50px;
		}
	}



</style>



	<center><h3 id="page-title">Informazioni su Codici KM Auto</h3></center>



	<?php
		if($this->session->flashdata('success_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('success_msg'); ?>
		</div>
	<?php		
		}
	?>


	<?php
		if($this->session->flashdata('error_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('error_msg'); ?>
		</div>
	<?php		
		}
	?>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#car_data').DataTable();
	} );

</script>



	<div align="">
			<a href="<?php echo base_url('admin/managed_codici/add'); ?>" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span> Aggiungere Nuovo</a>
			<a href="<?php echo base_url(); ?>admin/managed_codici/deletealldata" class="btn btn-danger" id="deleteall" onclick="return confirm('Vuoi Eliminare Tutti i Dati Permanentemente?');"><span class="glyphicon glyphicon-remove-circle"></span> Eliminare Tutti Dati</a>
	</div><br>

<div class="table-responsive">
	<table id="car_data" class="table">
		<thead class="thead-light">
			<tr>
				<th>Codice</th>
				<th>Categoria</th>
				<th>Creato</th>
				<th>Aggiornato</th>
				<th>Modificare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			if($codici){
				foreach($codici as $codice){
		?>
			<tr>
				<td><?php echo $codice->nome; ?></td>
				<td><?php echo $codice->categoria; ?></td>
				<td><?php echo $codice->created_at; ?></td>
				<td><?php echo $codice->updated_at; ?></td>
				<td>

					<a href="<?php echo base_url('admin/managed_codici/edit/'.$codice->id); ?>" class="btn btn-info"><span class="glyphicon glyphicon-edit"></span></a>
					<a href="<?php echo base_url('admin/managed_codici/delete/'.$codice->id); ?>" class="btn btn-danger" onclick="return confirm('Vuoi davvero eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a>

				</td>
			</tr>

		<?php
				}
			}
		?>
		</tbody>
	</table>
</div>



<br>
<br>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#codice_data').DataTable();
	} );

</script>





	<center><h3 id="page-title">Motivo</h3></center>


	<div align="">
			<a href="<?php echo base_url('admin/managed_codici/add_motivo'); ?>" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span> Aggiungere Motivo</a>
	</div><br>

<div class="table-responsive">
	<table id="codice_data" class="table">
		<thead class="thead-light">
			<tr>
				<th>Motivo</th>
				<th>Creato</th>
				<th>Aggiornato</th>
				<th>Modificare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			if($motivo){
				foreach($motivo as $motiv){
		?>
			<tr>
				<td><?php echo $motiv->motivo; ?></td>
				<td><?php echo $motiv->created_at; ?></td>
				<td><?php echo $motiv->updated_at; ?></td>
				<td>

					<a href="<?php echo base_url('admin/managed_codici/edit_motivo/'.$motiv->id); ?>" class="btn btn-info"><span class="glyphicon glyphicon-edit"></span></a>
					<a href="<?php echo base_url('admin/managed_codici/delete_motivo/'.$motiv->id); ?>" class="btn btn-danger" onclick="return confirm('Vuoi davvero eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a>

				</td>
			</tr>

		<?php
				}
			}
		?>
		</tbody>
	</table>
</div>



