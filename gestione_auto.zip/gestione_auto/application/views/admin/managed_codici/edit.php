<br>		

	<a href="<?php echo base_url('admin/managed_codici/index'); ?>" style="float: right;" class="btn btn-dark"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Indietro</a> <br> <br>

	<h3>Modificare Codici KM Auto Dettagli</h3> <br>

<!-- 	<center> -->
		<form action="<?php echo base_url('admin/managed_codici/update') ?>" method="post" class="form-horizontal">
		<input type="hidden" name="txt_hidden" value="<?php echo $codice->id; ?>">


		<div class="form">
			<label for="title">Nome Codice</label>
			<div class="col-md-3">
				<input name="nome"  value="<?php echo $codice->nome; ?>" class="form-control"></input>
			</div>

			<label for="description">Categoria</label>
			<div class="col-md-3">
				<select name="categoria" class="form-control">
					<option selected hidden><?php echo $codice->categoria; ?></option>
					<option value="Aziendine/Lavoro">Aziendine/Lavoro</option>
					<option value="Codice F">Codice F</option>
					<option value="Codice M">Codice M</option>
					<option value="Codici Colori">Codici Colori</option>
					<option value="Codici Vari">Codici Vari</option>
				</select>
			</div>

		</div>

		<br>

		<div class="form-group">
			<div class="col-md-4">
				<input type="submit" name="btnUpdate" class="btn btn-primary" value="Aggiorna">
			</div>
		</div>
	</form>
<!-- </center>
 -->
