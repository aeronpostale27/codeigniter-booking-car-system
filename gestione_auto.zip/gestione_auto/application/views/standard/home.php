<!DOCTYPE html>
<html>
<head>
	<title>Montet - Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap.css')?>">
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-3.3.1.min.js')?>"></script>
	<script type="text/javascript" src="<?php echo site_url('assets/bootstrap/dist/js/bootstrap.js')?>"></script>
	<link href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap-glyphicons.css')?>" rel="stylesheet">
</head>

<style type="text/css">

	.btn-primary {
	    color: #fff;
	    background-color: #369fd6;
	    border-color: #369fd6;
	}

/*	.btn-primary:hover {
	    color: #424242;
	    background-color: #fffb78;
	    border-color: #fffb78;
	}*/
	
	body {
		background-color: #fffb78;
	}

	#logox {
		  width: 100%;
	   }

	
	
</style>

<body>


	<div class="text-center">
		        <img id="logox" src="<?php echo site_url('assets/bootstrap/assets/img/mc-finale.jpg')?>" alt="">
    </div> 

	<div class="container">
		
       
		<div class="row">
			<div class="col-lg"></div>
    		<div class="col-sm" id="login">


		<?php echo form_open("home/verify"); ?>

		  <div class="form-group">
		    <?php echo form_error('name'); ?>		
		    <label for="">Nome Utente</label>
		    <input name="name" type="text" class="form-control" value="<?php echo set_value('name'); ?>" placeholder="Nome Utente">
		  </div>
		  <div class="form-group">
		  	<?php echo form_error('password'); ?>
		    <label for="">Password</label>
		    <input name="password" type="password" class="form-control" value="<?php echo set_value('password'); ?>" placeholder="Password">
		  </div>
		 
		  <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span>&nbsp; Vai</button> 

		<?php echo form_close(); ?>


			</div>

			<div class="col-sm"></div>
		</div>


</body>
</html>

<center>
	<div class="fixed-bottom" style="padding: 10px; color: #000000; background-color: #c5c2568f; font-size: 10pt;">
		<script type="text/javascript">	var theDate = new Date();document.write("Copyright &copy; 2018 - " + theDate.getFullYear() + " Movimento dei Focolari - Montet | Designed by: Graphic Montet 2018 - 2019"); </script>
	</div>
</center>

</footer>
