<!DOCTYPE html>
<html>
<head>
	<title>Focolare - Montet</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/imagehover.min.css')?>">
	
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-3.3.1.min.js')?>"></script>
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui.min.js')?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap.css')?>">

	<script type="text/javascript" src="<?php echo site_url('assets/bootstrap/dist/js/bootstrap.js')?>"></script>
	<link href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap-glyphicons.css')?>" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/DataTables/datatables.min.css') ?>"/>
	<script type="text/javascript" src="<?php echo site_url('assets/DataTables/datatables.min.js') ?>"></script>

	<script type="text/javascript" src="<?php echo site_url('assets/js/moment.min.js') ?>"></script>
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery.fittext.min.js') ?>"></script>

	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui-timepicker-addon.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/jquery-ui.min.css') ?>"/>
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui-timepicker-addon.js') ?>"></script>
	
	<script type="text/javascript" src="<?php echo site_url('assets/js/datepicker_form.js') ?>"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<style type="text/css">
		.navbar-light .navbar-nav .nav-link {
		    color: white;
		}

		body {
			padding-bottom: 45px;
		}

		@media (min-width: 1250px) {
		.container {
		    max-width: 1456px;
		}
	}
</style>

<body>
	<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #fffb78">

	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	
	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">

		 <li class="nav-item">
	          <a class="nav-link" href="<?php echo site_url('standard/standard_dashboard')?>"><div style="color: #424242; font-weight: 500;">Focolari - Montet &nbsp;<span style="color: #424242;" class="glyphicon glyphicon-home"></div></span></a>
	     </li>

	    </ul>

        <div class="" align="" aria-labelledby="navbarDropdown">
          <a class="btn btn-danger" href="<?php echo site_url('standard/user_dashboard/logout')?>"><span class="glyphicon glyphicon-log-out"></span> Disconnetti</a>
        </div>

	  </div>

</nav>

<div class="container">