<style>

	.btn-primary {
        color: #ffffff;
	    background-color: #369fd6;
	    border-color: #ffffff;
	}

	.btn-primary:hover {
	    color: #424242;
	    background-color: #fffb78;
	    border-color: #fffb78;
	}

</style>

	

	<div style="float:right; margin-top: 20px;"><a href="<?php echo base_url('standard/standard_dashboard/index'); ?>" class="btn btn-dark"><span class="glyphicon glyphicon-arrow-left"></span> Indietro</a></div><br> <br><br> <br>
	


	<center><h3>Mettere Chilometraggio</h3></center>

	<center><form action="<?php echo base_url('standard/standard_report/update_mileage') ?>" method="post" class="form-horizontal">
		<input type="hidden" name="txt_hidden" value="<?php echo $report->id; ?>">

		<div class="form-group">
			<label for="mileage" class="col-md-2"></label>
			<?php echo form_error('mileage'); ?>
			<div class="col-md-2">
				<input type="text" minlength="6" maxlength="6" name="mileage" class="form-control" value="<?php echo $report->mileage; ?>" required>
			</div>
		</div>
		<div class="form-group">
			<div class="col-md-4">
				<input type="submit" name="btnUpdate" class="btn btn-primary" value="Salva">
			</div>
		</div>
	</form></center>
	

