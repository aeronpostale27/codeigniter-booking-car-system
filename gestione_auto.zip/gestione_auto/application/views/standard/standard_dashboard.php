<style type="text/css">
	
	.table .thead-light th {
	    color: #424242;
	    background-color: #fffb78;
	    border-color: #fffb78;
	}

	.table {
		border: solid 3px; 
		border-color: #fffb78;
	}

	#title-header {
		margin-top: 0px;
		margin-bottom: 15px;
		text-align: center;
	}

	.btn-primary {
	    color: white;
	    background-color: #369fd6;
	    border-color: #fffb78;
	}

	.page-item.active .page-link {
	    z-index: 1;
	    color: #424242;
	    background-color: #fffb78;
	    border-color: #fffb78;
	}

	.form-control {
	    border: 1px solid #fffb78;
	}

	select option[disabled='disabled'] {
        color: white;
        background: #c82333;
    }

    .page-link {
	    color: #424242;

	}
	
	input:required:focus {
	  border: 3px solid #dc3545;
	  outline: none;
	}

	input:required:hover {
	  opacity: 3;
	}

	select:required:hover {
	  opacity: 3;
	}

	select:required:focus {
	  border: 3px solid #dc3545;
	  outline: none;
	}

	span#except {
		color: red;
		font-weight: bold;
		font-style: italic;
	}

	.btn-info {
        color: #ffffff;
	    background-color: #369fd6;
	    border-color: #ffffff;
	}

	.btn-info:hover {
	    color: #424242;
	    background-color: #fffb78;
	    border-color: #fffb78;
	}

	.clock {
	  height: 70px;
/*	  width: 50%;*/
	  line-height: 70px;  
	  margin: 50px auto 30px;
	  padding: 0 35px;
	  background: #369fd6;
	  color: #ffffff;
	  font-size: 16pt;
/*	  float: right;*/
	  border-radius: 15px;
      box-shadow: 0 0 7px #369fd6;
   	  text-shadow: 0 0 0px #212529;
	}

	#form1 {
		padding: 40px;
	    border-radius: 20px;
	    background: #fffb78;
	    margin-top: 40px;
	}

	#form2 {
		padding: 40px;
	    border-radius: 20px;
	    background: #fffb78;
	    margin-top: 80px;
	    margin-bottom: 50px;

	}

	.form-control[readonly] {
	    background-color: #ffffff;
	    opacity: 1;
	}

	div.dataTables_filter input {
	    border: 1px solid #424242 !important;
	}

	.custom-select {
		border: 1px solid #424242 !important;
	}

	@media screen and (max-width: 800px) {
	   .clock {
	      font-size: 15pt;
	   }

	   .col-3 {
		    -webkit-box-flex: 0;
		    -ms-flex: 0 0 25%;
		    flex: 0 0 50%;
   			max-width: 50%;
		}

		.col-2 {
		    -webkit-box-flex: 0;
		    -ms-flex: 0 0 16.666667%;
		    flex: 0 0 50%;
   			max-width: 50%;
		}

		.col-4 {
	        -webkit-box-flex: 0;
		    -ms-flex: 0 0 50%;
	        flex: 0 0 50%;
   			max-width: 50%;
		}
	}

	@media (min-width: 1250px) {
		.container {
		    max-width: 1700px;
		}
	}

</style>


<script type="text/javascript">

	$(document).ready(function() {
	    $('#booking').DataTable();
	} );



	$('#clock').fitText(1.3);

	function update() {
	  $('#clock').html(moment().format('dddd - D MMMM YYYY H:mm:ss'));
	}

	setInterval(update, 1000);

</script>


<div class="row">
	<span id="clock" class="clock">aspettando ...</span>
</div>





<script type="text/javascript">

	$(document).ready(function() {
	    $('#reports').DataTable( {
	        "order": [[ 0, "desc" ]]
	    } ); 
	} );

</script>



<div class="table-responsive">
	<table id="reports" class="table">
		<thead class="thead-light">
			<tr>
				<th>ID</th>
				<th>Autista</th>
				<th>Macchina Usato</th>
				<th>Codice</th>
				<th>Motivo</th>
				<th>Nota</th>
				<th>Destinazione</th>
				<th>Dal Giorno/Tempo</th>
				<th>Fino Giorno/Tempo</th>
				<th>Chilometraggio</th>
				<th>Mettere Chilometraggio</th>
				<th>Modificare</th>
				<th>Cancellare</th>
			</tr>
		</thead>
		<tbody>
		<?php 
				foreach($reports as $report) {

				setlocale(LC_ALL, 'it_IT.UTF-8');


		?>


			<tr>
				<td><?php echo $report->id; ?></td>
				<td><?php echo $report->driver_name; ?></td>
				<td><?php echo $report->car_name; ?></td>
				<td><?php echo $report->code; ?></td>
				<td><?php echo $report->code_add; ?></td>
				<td><?php echo $report->note; ?></td>
				<td><?php echo $report->destination; ?></td>
		 		<!-- <td><?php echo strftime("%a %d %b %H:%M", strtotime($report->from_day))."<br/>"; ?></td> -->
				<td><?php echo $report->from_day; ?></td>
				<td><?php echo $report->to_day; ?></td>
				<td><?php echo $report->mileage; ?></td>

				<td>
					<a href="<?php echo base_url('standard/standard_report/edit/'.$report->id); ?>" class="btn btn-info">Mettere qua</a>
				</td>
				<td>
					<a href="<?php echo base_url('standard/standard_report/modif/'.$report->id); ?>" class="btn btn-info">Modificare</a>
				</td>
				<td>
					<center><a href="<?php echo base_url('standard/standard_report/delete/'.$report->id); ?>" class="btn btn-danger" onclick="return confirm('Vuoi davvero eliminare?');"><span class="glyphicon glyphicon-remove-circle"></span></a></center>
				</td>
			</tr>
		<?php
				}
		?>
		</tbody>
	</table>
</div>






<div class="form_error">
<?php echo validation_errors(); ?>
</div>


<form action="<?php echo base_url('standard/standard_form/submit') ?>" method="post" class="form-horizontal" id="form2">

		<h1 id="title-header"> Prenotazione </h1> 
		<br>

		<div class="form-group row">
		  <div class="col-6">
		  	<label for="">Austista</label>
		  	<input class="form-control" type="text" name="driver_name" value="<?php echo set_value('name'); ?>" placeholder="Mettere Austista Nome" required>
		  </div>

		 <div class="col-6">
		  	<label for="">Macchina</label>
		    <select name="car_id" id="exception" class="form-control" required>
	    		<option disabled selected value="">Scegliere Libero Macchina</option>

		    	 <?php 
			        foreach($cars_avail as $car_avail) 
			        { 
			          echo '<option value="'.$car_avail->car_name.'">'.$car_avail->car_name . ' '. $car_avail->exception. $car_avail->attention.'</option>';
			        }
		        ?>
		    </select>
		  </div> 
		</div>



<script type="text/javascript">

	var d = new Date();
    var n = d.getDay()

    var get;

	    if (n == 1) {
	    	$("select option:contains('- Lunedi')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mar')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mer')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Gio')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Dom')").attr("disabled","disabled");
	    } else if (n == 2) {
	    	$("select option:contains('- Martedi')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Mer')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Gio')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mar')").attr("disabled","disabled");
	    } else if (n == 3) {
	    	$("select option:contains('- Mercoledi')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Gio')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Mer')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Mer')").attr("disabled","disabled");
	    } else if (n == 4) {
	    	$("select option:contains('- Giovedi')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Gio')").attr("disabled","disabled");	
	    	$("select option:contains('- Mar|Gio')").attr("disabled","disabled");   
	    	$("select option:contains('- Mer|Gio')").attr("disabled","disabled"); 	
	    } else if (n == 5) {
	    	$("select option:contains('- Venerdi')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Ven')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Ven')").attr("disabled","disabled");
	    } else if (n == 6) {
	    	$("select option:contains('- Sabato')").attr("disabled","disabled");
	    	$("select option:contains('- Sab|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Sab')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Sab')").attr("disabled","disabled");
	    } else if (n == 7) {
	    	$("select option:contains('- Domenica')").attr("disabled","disabled");
	    	$("select option:contains('- Lun|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Mar|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Mer|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Gio|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Ven|Dom')").attr("disabled","disabled");
	    	$("select option:contains('- Sab|Dom')").attr("disabled","disabled");
	    } else {
	    	// alert('good');
	    }

</script>




		<br>
		<div class="form-group row">
		  <div class="col-2">
		  	<label for="">Codice</label>
		    <select name="code" class="form-control" required>
		    	<option value="">Codice</option>
		    	<?php 
			        foreach($codici as $codice)
			        { 
			          echo '<option value="'.$codice->nome.'">'.$codice->nome .'</option>';
			        }
		        ?>
		    </select>
		  </div>

		  <div class="col-2">
		  	<label for="">Motivo</label>
		    <select name="code_add" type="text" class="form-control">
		    	<option value="">Motivo</option>
		    	<?php 
			        foreach($motivo as $motiv)
			        { 
			          echo '<option value="'.$motiv->motivo.'">'.$motiv->motivo .'</option>';
			        }
		        ?>
		    </select>
		  </div>

		  <div class="col-4">
		  	<label for="">Nota</label>
		    <input class="form-control" type="text" placeholder="Nota" name="note">
		  </div>

		  <div class="col-4">
		  	<label for="">Destinazione</label>
		    <input class="form-control" type="text" value="<?php echo set_value('destination'); ?>" placeholder="Destinazione" name="destination">
		  </div>
		</div>

		<div class="form-group row">
		  <div class="col-3">
		  	<?php echo form_error('from_day'); ?>
		  	<label for="">Dal Giorno & Tempo</label>
		    <input id="txtFromDate" class="form-control" type="text" value="<?php echo set_value('from_day'); ?>" placeholder="Dal Giorno & Tempo" minlength="16" maxlength="16" name="from_day" required>
		  </div>
	

		  <div class="col-3">
		  	<?php echo form_error('to_day'); ?>
		  	<label for="">Fino Giorno & Tempo</label>
		    <input id="txtToDate" class="form-control" type="text" value="<?php echo set_value('to_day'); ?>" placeholder="Fino Giorno & Tempo" minlength="16" maxlength="16" name="to_day" required>
		  </div>


		</div>

		<div class="form-group row">
		  <div class="col-4">
		    <input type="submit" name="submit" class="btn btn-primary" value="Salva">
		  </div>
		</div>


		

</form>

	



