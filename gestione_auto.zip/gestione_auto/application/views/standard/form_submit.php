<html>
<head>
	<title>Grazie! Buon Viaggio!</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/imagehover.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap.css')?>">
	<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-3.3.1.min.js')?>"></script>
	<script type="text/javascript" src="<?php echo site_url('assets/bootstrap/dist/js/bootstrap.js')?>"></script>
	<link href="<?php echo site_url('assets/bootstrap/dist/css/bootstrap-glyphicons.css')?>" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/DataTables/datatables.min.css') ?>"/>
	<script type="text/javascript" src="<?php echo site_url('assets/DataTables/datatables.min.js') ?>"></script>
</head>



<div class="col-xs-1" align="center" style="margin-top: 100px; padding-right: 18px;">
  <img src="<?php echo base_url("assets/bootstrap/assets/img/icons/check.svg"); ?>" height="280px;">
  <h1 class="display-3" style="color: #4caf50;">BUON VIAGGIO!</h1>
  <p class="lead">Per favore non dimenticare a scrivere<b><strong> CHILOMETRAGGIO</strong></b> dopo. GRAZIE MILLE!</p>
  <hr>
  <p class="lead">
  <a class="btn btn-primary btn-sm" href="<?php echo site_url('standard/standard_dashboard')?>" role="button"><span class="glyphicon glyphicon-home"></span> Home</a>
  <a class="btn btn-danger btn-sm" href="<?php echo site_url('standard/user_dashboard/logout')?>" role="button"><span class="glyphicon glyphicon-log-out"></span> Disconnetti</a>
  </p>
</div>



</html>