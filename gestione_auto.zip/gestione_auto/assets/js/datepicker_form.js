	$(document).ready(function(){
	    $("#txtFromDate").datetimepicker({
	    	dateFormat: 'dd/mm/yy',
	        numberOfMonths: 1,
	        onSelect: function(selected) {
	          $("#txtToDate").datetimepicker("option","minDate", selected)
	        }
	    });

	    $("#txtToDate").datetimepicker({ 
	    	dateFormat: 'dd/mm/yy',
	        numberOfMonths: 1,
	        onSelect: function(selected) {
	           $("#txtFromDate").datetimepicker("option","maxDate", selected)
	        }
	    });  
	});
